from django.contrib import admin
from app1_output.models import AnaSummary
admin.site.register(AnaSummary)
# Register your models here.
