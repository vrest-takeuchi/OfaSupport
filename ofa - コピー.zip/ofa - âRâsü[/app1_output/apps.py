from django.apps import AppConfig


class App1OutputConfig(AppConfig):
    name = 'app1_output'
