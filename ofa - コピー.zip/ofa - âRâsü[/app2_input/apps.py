from django.apps import AppConfig


class App2InputConfig(AppConfig):
    name = 'app2_input'
