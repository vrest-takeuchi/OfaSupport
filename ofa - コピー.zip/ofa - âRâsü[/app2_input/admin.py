from django.contrib import admin
from app2_input.models import EquipMeasurementTbl
admin.site.register(EquipMeasurementTbl)
# Register your models here.
